package com.alosha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuartzschedulerApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuartzschedulerApplication.class, args);
	}

}

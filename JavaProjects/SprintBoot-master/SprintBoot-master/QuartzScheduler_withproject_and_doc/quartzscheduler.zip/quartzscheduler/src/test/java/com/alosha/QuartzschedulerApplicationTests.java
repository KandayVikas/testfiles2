package com.alosha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuartzschedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}

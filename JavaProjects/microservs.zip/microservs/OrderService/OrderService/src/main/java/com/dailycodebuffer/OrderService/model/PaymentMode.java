package com.dailycodebuffer.OrderService.model;

public enum PaymentMode {
    CASH,
    CREDIT_CARD,
    DEBIT_CARD,
    GPAY
}
